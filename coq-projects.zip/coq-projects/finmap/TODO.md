- notation for constants
- Basculer finsfun -> fsfun
- Documenter les manières de constuire des fsfun et expliquer comment
   faire à partir d'une séquence
- Map à partir d'une liste d'association
- Map singleton
- finsupp -> fsupp Documenter !
- lock [fmap -> _] or at least setf getf
- 