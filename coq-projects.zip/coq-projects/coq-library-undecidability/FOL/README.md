# On Synthetic Undecidability in Coq, with an Application to the Entscheidungsproblem

Yannick Forster <forster@ps.uni-saarland.de>,
Dominik Kirst <kirst@ps.uni-saarland.de>,
Gert Smolka <smolka@ps.uni-saarland.de>

Saarland University

The paper and the compiled HTML version of the Coq files can be found at https://ps.uni-saarland.de/extras/fol-undec.

## How to compile the code

`make` should do the job. The files are tested to compile with `The Coq Proof Assistant, version 8.8.2 (October 2018)`.


