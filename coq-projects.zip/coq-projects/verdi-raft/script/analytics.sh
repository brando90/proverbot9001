#!/usr/bin/env bash
./configure
make proofalytics
