#!/usr/bin/env sh

ruby pp.rb
coq_makefile -f Make -o Makefile
