# ![Logo](https://raw.githubusercontent.com/clarus/icons/master/street-light-48.png) System
The monad and API definitions.
