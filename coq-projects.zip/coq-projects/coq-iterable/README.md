# Iterable
> Generic definition of iterators.

    opam install coq-iterable
