#!/bin/sh

coq_makefile -f Make -o Makefile

