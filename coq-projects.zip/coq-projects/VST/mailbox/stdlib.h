#include <sys/types.h>

void *malloc(size_t size);
void exit(int ExitCode);
