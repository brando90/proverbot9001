Copyright for each contribution belongs to the contributor that provided it. Each contributor has agreed to the GitHub CLA, and has therefore agreed to license all contributions according to the terms of the LICENSE file in affect at the time of the contribution.

List of contributors:
https://github.com/adampetcher/fcf/graphs/contributors

For details about contributors and contributions:
git blame <filename>

GitHub CLA:
https://cla.github.com