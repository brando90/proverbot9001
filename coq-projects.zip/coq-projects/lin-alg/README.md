# Linear Algebra

The Linear Algebra distribution by Jasper Stein (jasper@cs.kun.nl) extending the
(required) [algebra distribution by Loic Pottier][loic], and following Chapter 1
of "Linear Algebra" by Friedberg, Insel and Spence.

Available as package `coq-lin-alg` via [OPAM][opam].

Share and enjoy!
Jasper Stein

[loic]: https://github.com/coq-contribs/algebra
[opam]: https://coq.inria.fr/opam/www/using.html
